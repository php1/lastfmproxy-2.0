
# Port and address to listen to
listenport = 1881
bind_address = "127.0.0.1"

# Stick your last.fm username and password between the quotes below.
username = "yourusername"
password = "yourpassword"

# Which theme (skin) to use
theme = "default"

# Change "useproxy" to True and set the host and port if 
# you need an external proxy.
useproxy = False
proxyhost = "my.proxy.host"
proxyport = 8000
# Set these if your proxy requires authentication.
# Note: Only "Basic" authentication is supported.
proxyuser = ""
proxypass = ""

